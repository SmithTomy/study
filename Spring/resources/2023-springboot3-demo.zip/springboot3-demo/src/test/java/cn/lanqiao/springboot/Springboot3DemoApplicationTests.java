package cn.lanqiao.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot3DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
