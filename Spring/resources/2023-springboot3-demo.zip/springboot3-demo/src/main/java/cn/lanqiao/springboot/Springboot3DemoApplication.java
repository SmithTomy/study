package cn.lanqiao.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3DemoApplication.class, args);
	}

}
